# Amma Nursing Care Website
Responsive, colourful website for Amma Nursing Care.

## Publish on GitHub Pages
1. Create a new public repository named `amma-nursing-care`.
2. Upload `index.html` and the full `assets` folder (keep the folder structure).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish the site; the public address appears in the Pages section.

Phone numbers, service descriptions and other text can be edited in `index.html`.
